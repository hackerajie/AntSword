/*
<T>XDB</T>
<X>
oracle.jdbc.driver.OracleDriver
jdbc:oracle:thin:user/password@127.0.0.1:1521/test
</X>
*/

module.exports = require('./default');